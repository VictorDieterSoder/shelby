# Verificação da entrega

As verificações abaixo são históricas e se referem à versão Cantina anterior à adoção
de `Hackathon2.mwb`. Elas não validam o esquema atualizado desta entrega. Importe o SQL
em um banco de teste e execute os procedimentos após configurar PHP/MySQL.

## Executado durante a montagem

- Verificação de sintaxe do JavaScript pelo Node (`node --check`).
- Verificação sintática do script Python de testes e do inicializador PowerShell.
- Conferência da estrutura SQL: 15 tabelas, referências de chaves estrangeiras e
  12 produtos iniciais.
- Teste das telas em navegador com **API simulada**, sem PHP ou MySQL: login de
  responsável e aluno; painel; envio de limite e recarga; carrinho; escolha de
  retirada; confirmação; histórico; carrinho vazio após compra.
- Inspeção visual do painel no navegador e consulta de erros de console no fluxo
  testado, sem erros registrados.
- Conferência do ZIP e preservação dos arquivos originais.

## Não executado neste ambiente

Não foram encontrados PHP ou MySQL Server instalados. Por isso:

- Não foi possível executar `php -l` ou testar o backend PHP em execução.
- O SQL não foi importado em um MySQL real durante a montagem.
- O teste integrado `tests/teste_api.py` foi preparado, mas não foi executado contra
  o backend real. Validação de autorização, transações e concorrência requer esse
  ambiente; o teste automatizado fornecido cobre o fluxo sequencial e reenvios,
  não uma prova de concorrência.

Os testes com API simulada verificam somente o comportamento das telas. Não
confirmam persistência ou integridade dos dados no MySQL.

## Teste recomendado após configurar o MySQL

1. Importe o SQL em uma base nova de teste.
2. Configure `config/config.php` e mantenha a recarga de demonstração habilitada.
3. Execute a verificação de sintaxe PHP indicada no LEIA-ME.
4. Inicie `php -S localhost:8000 -t public`.
5. Execute `python tests/teste_api.py http://localhost:8000`.

O script cria contas fictícias e verifica login, CSRF, isolamento entre responsáveis,
recarga, transferência, limites, preços calculados no servidor, pedidos, extrato e
reenvio da mesma operação. Ele deixa os registros no banco de teste para inspeção.

Para testar concorrência depois, use um servidor PHP com múltiplos workers e duas
sessões do mesmo aluno. Faça compras simultâneas cuja soma ultrapasse o saldo ou o
limite: somente as operações compatíveis com o saldo e o limite devem ser aceitas.
