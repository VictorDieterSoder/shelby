<?php
declare(strict_types=1);

return [
    'host' => '127.0.0.1',
    'port' => 3306,
    'database' => 'cantina',
    'username' => 'cantina_app',
    'password' => 'SUBSTITUA_PELA_SENHA_DO_MYSQL',
    'timezone' => 'America/Sao_Paulo',
    // Somente para estudo: permite adicionar crédito fictício. Não processa pagamentos.
    'demo_recharge' => true,
];
